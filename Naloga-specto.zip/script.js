console.log("HI");

// function submitForm() {
//   console.log("Handle click");
//   return false;
// }

document.getElementById("message-form").onsubmit = e => {
  e.preventDefault();

  document
    .querySelector('fieldset[form="message-form"]')
    .classList.add("disabled");

  document.querySelector('fieldset[form="message-form"]').disabled = true;

  const message = document.querySelector('textarea[name="message"]').value;
  const gender = document.querySelector('input[name="gender"]:checked').value;
  const name = document.querySelector('input[name="name"]').value;
  const email = document.querySelector('input[name="email"]').value;

  let data = {
    message,
    gender,
    name,
    email
  };
  console.log(data);
};
